from os import environ
import uuid
import json
import random


if __name__ == '__main__':
    count = environ.get("count")
    loans_count = environ.get("loans_count")
    if not count:
        exit(0)
    count = int(count)
    if not loans_count:
        loans_count = int(count/10)

    instances, holdings, items, circulates = [], [], [], []
    instances_from_csv, holdings_from_csv, circulate_from_csv, items_from_csv = [], [], [], []
    available_items, checked_out_items = [], []
    with open("/instances.tsv", 'r', encoding="utf-8") as tsv:
        for line in tsv.read().split("\n"):
            try:
                instances_from_csv.append(json.loads(line.split("\t")[1]))
            except Exception as e:
                print(e)
    with open("/recordholdings.tsv", 'r', encoding="utf-8") as tsv:
        for line in tsv.read().split("\n"):
            try:
                holdings_from_csv.append(json.loads(line.split("\t")[1]))
            except Exception as e:
                print(e)
    with open("/items.tsv", 'r', encoding="utf-8") as tsv:
        for line in tsv.read().split("\n"):
            try:
                items_from_csv.append(json.loads(line.split("\t")[1]))
            except Exception as e:
                print(e)
    with open("/circulate.tsv", 'r', encoding="utf-8") as tsv:
        for line in tsv.read().split("\n"):
            try:
                circulate_from_csv.append(json.loads(line.split("\t")[1]))
            except Exception as e:
                print(e)
    if count > 0:
        for i in range(count):
            instance_id = str(uuid.uuid4())
            instance = instances_from_csv[random.randint(0, len(instances_from_csv) - 1)]
            instance['id'] = instance_id
            instances.append(instance_id + "\t" + json.dumps(instance) + "\n")
            count -= 1
            if count == 0:
                break
    for instance in instances:
        holding_id = str(uuid.uuid4())
        holding = holdings_from_csv[random.randint(0, len(holdings_from_csv) - 1)]
        holding['id'] = holding_id
        holding['instanceId'] = instance.split("\t")[0]
        holdings.append(holding_id + "\t" + json.dumps(holding) + "\t" + holding['permanentLocationId'] + "\n")

    available_count = len(holdings) - loans_count
    for holding in holdings:
        item_id = str(uuid.uuid4())
        item = items_from_csv[random.randint(0, len(items_from_csv) - 1)]
        item['barcode'] = random.randint(100000000, 9999999999)
        item['holdingsRecordId'] = holding.split("\t")[0]
        item['id'] = item_id
        if available_count > 0:
            item['status']['name'] = 'Available'
            available_items.append(item)
        else:
            item['status']['name'] = 'Checked out'
            checked_out_items.append(item_id)
            circulate = circulate_from_csv[random.randint(0, len(circulate_from_csv) - 1)]
            circulate['id'] = str(uuid.uuid4())
            circulate['itemId'] = item_id
            circulates.append(item_id + "\t" + json.dumps(circulate) + "\n")
        available_count -= 1
        items.append(item_id + "\t" + json.dumps(item) + "\t\\N\t\\N\t" + item['holdingsRecordId'] + "\n")

    with open("/tmp/instances.tsv", 'w') as file:
        for instance in instances:
            file.write(str(instance))
    with open("/tmp/recordholdings.tsv", 'w') as file:
        for holding in holdings:
            file.write(str(holding))
    with open("/tmp/items.tsv", 'w') as file:
        for item in items:
            file.write(str(item))
    with open("/tmp/circulate.tsv", 'w') as file:
        for circulate in circulates:
            file.write(str(circulate))
    with open("/tmp/available.csv", 'w') as file:
        for line in items:
            item = json.loads(line.split("\t")[1])
            if item['status']['name'] == 'Available':
                file.write(str(item['barcode']) + ',Available' + '\n')
    with open("/tmp/checked_out.csv", 'w') as file:
        for line in items:
            item = json.loads(line.split("\t")[1])
            if item['status']['name'] == 'Checked out':
                file.write(str(item['barcode']) + ',Not_available' + '\n')
