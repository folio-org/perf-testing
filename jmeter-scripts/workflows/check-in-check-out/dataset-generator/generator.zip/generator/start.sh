#!/bin/bash

python generator.py